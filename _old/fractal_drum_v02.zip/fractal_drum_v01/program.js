const LEVELS = 4;
const treeArea = document.getElementById('treeArea');
const nodesLayer = document.getElementById('nodes');
const branchesSvg = document.getElementById('branches');
const machine = document.querySelector('.machine');
const track1 = document.getElementById('track1');
const tempo = document.getElementById('tempo');
const tempoKnob = document.getElementById('tempoKnob');
const tempoValue = document.getElementById('tempoValue');
const knobIndicator = document.querySelector('#tempoKnob span');

const W = 200;
const H = 380;
const yLevels = [326, 238, 150, 62];
const nodes = [];

function nodePosition(level, index) {
  const count = 2 ** level;
  const sidePadding = level === LEVELS - 1 ? 7 : 18;
  const usableWidth = W - sidePadding * 2;
  const x = sidePadding + ((index + 0.5) / count) * usableWidth;
  const y = yLevels[level];
  return { x, y };
}

function buildTree() {
  nodesLayer.innerHTML = '';
  branchesSvg.innerHTML = '';
  nodes.length = 0;

  for (let level = 0; level < LEVELS; level++) {
    const count = 2 ** level;
    nodes[level] = [];

    for (let i = 0; i < count; i++) {
      const { x, y } = nodePosition(level, i);
      const button = document.createElement('button');
      button.className = 'node';
      button.type = 'button';
      button.style.left = `${(x / W) * 100}%`;
      button.style.top = `${(y / H) * 100}%`;
      button.setAttribute('aria-pressed', 'false');
      button.title = `Level ${level + 1}, node ${i + 1}`;

      button.addEventListener('click', () => {
        const isActive = button.classList.toggle('active');
        button.setAttribute('aria-pressed', String(isActive));
      });

      nodesLayer.appendChild(button);
      nodes[level][i] = button;

      if (level > 0) {
        const parentIndex = Math.floor(i / 2);
        const parent = nodePosition(level - 1, parentIndex);
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', parent.x);
        line.setAttribute('y1', parent.y);
        line.setAttribute('x2', x);
        line.setAttribute('y2', y);
        line.setAttribute('class', 'branch');
        branchesSvg.appendChild(line);
      }
    }
  }
}

function alignTreeToTrack() {
  const machineRect = machine.getBoundingClientRect();
  const buttonRect = track1.getBoundingClientRect();
  const buttonCenter = buttonRect.left - machineRect.left + buttonRect.width / 2;
  const treeWidth = treeArea.offsetWidth;
  treeArea.style.left = `${buttonCenter - treeWidth / 2}px`;
}

function setTempo(bpm) {
  const min = Number(tempo.min);
  const max = Number(tempo.max);
  const clamped = Math.max(min, Math.min(max, Math.round(bpm)));
  tempo.value = String(clamped);
  tempoValue.value = `${clamped} BPM`;

  // Classic hardware-style sweep: about 7:30 to 4:30.
  const t = (clamped - min) / (max - min);
  const degrees = 135 + t * 270;
  knobIndicator.style.transform = `rotate(${degrees}deg)`;
}

track1.addEventListener('click', () => {
  const on = track1.getAttribute('aria-pressed') !== 'true';
  track1.setAttribute('aria-pressed', String(on));
  treeArea.classList.toggle('visible', on);
  treeArea.setAttribute('aria-hidden', String(!on));
  alignTreeToTrack();
});

tempoKnob.addEventListener('wheel', (event) => {
  event.preventDefault();
  setTempo(Number(tempo.value) + (event.deltaY < 0 ? 1 : -1));
}, { passive: false });

let dragging = false;
let lastY = 0;

tempoKnob.addEventListener('pointerdown', (event) => {
  dragging = true;
  lastY = event.clientY;
  tempoKnob.setPointerCapture(event.pointerId);
});

tempoKnob.addEventListener('pointermove', (event) => {
  if (!dragging) return;
  const delta = lastY - event.clientY;
  if (Math.abs(delta) >= 1) {
    setTempo(Number(tempo.value) + delta);
    lastY = event.clientY;
  }
});

tempoKnob.addEventListener('pointerup', () => { dragging = false; });
tempoKnob.addEventListener('pointercancel', () => { dragging = false; });

tempoKnob.addEventListener('dblclick', () => setTempo(90));

window.addEventListener('resize', alignTreeToTrack);

buildTree();
alignTreeToTrack();
setTempo(Number(tempo.value));
