const LEVELS = 4;
const treeArea = document.getElementById('treeArea');
const nodesLayer = document.getElementById('nodes');
const branchesSvg = document.getElementById('branches');
const machine = document.querySelector('.machine');
const track1 = document.getElementById('track1');
const transport = document.getElementById('transport');
const tempo = document.getElementById('tempo');
const tempoKnob = document.getElementById('tempoKnob');
const tempoValue = document.getElementById('tempoValue');
const knobIndicator = document.querySelector('#tempoKnob span');

const W = 200;
const H = 380;
const yLevels = [326, 238, 150, 62];
const nodes = [];
const branchPulses = new Map();

let audioCtx = null;
let isPlaying = false;
let schedulerTimer = null;
let nextStepTime = 0;
let stepIndex = 0;
let currentPath = null;
const lookAheadMs = 25;
const scheduleAheadSec = 0.10;

function nodePosition(level, index) {
  const count = 2 ** level;
  const sidePadding = level === LEVELS - 1 ? 7 : 18;
  const usableWidth = W - sidePadding * 2;
  const x = sidePadding + ((index + 0.5) / count) * usableWidth;
  const y = yLevels[level];
  return { x, y };
}

function branchKey(childLevel, childIndex) {
  return `${childLevel}:${childIndex}`;
}

function buildTree() {
  nodesLayer.innerHTML = '';
  branchesSvg.innerHTML = '';
  nodes.length = 0;
  branchPulses.clear();

  for (let level = 0; level < LEVELS; level++) {
    const count = 2 ** level;
    nodes[level] = [];

    for (let i = 0; i < count; i++) {
      const { x, y } = nodePosition(level, i);
      const button = document.createElement('button');
      button.className = 'node';
      button.type = 'button';
      button.style.left = `${(x / W) * 100}%`;
      button.style.top = `${(y / H) * 100}%`;
      button.setAttribute('aria-pressed', 'false');
      button.title = `Level ${level + 1}, node ${i + 1}`;

      button.addEventListener('click', () => {
        const active = button.classList.toggle('active');
        button.setAttribute('aria-pressed', String(active));
      });

      nodesLayer.appendChild(button);
      nodes[level][i] = button;

      if (level > 0) {
        const parentIndex = Math.floor(i / 2);
        const parent = nodePosition(level - 1, parentIndex);

        const base = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        base.setAttribute('x1', parent.x);
        base.setAttribute('y1', parent.y);
        base.setAttribute('x2', x);
        base.setAttribute('y2', y);
        base.setAttribute('class', 'branch');
        branchesSvg.appendChild(base);

        const pulse = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        pulse.setAttribute('x1', parent.x);
        pulse.setAttribute('y1', parent.y);
        pulse.setAttribute('x2', x);
        pulse.setAttribute('y2', y);
        pulse.setAttribute('class', 'branch-pulse');
        branchesSvg.appendChild(pulse);
        branchPulses.set(branchKey(level, i), pulse);
      }
    }
  }
}

function alignTreeToTrack() {
  const machineRect = machine.getBoundingClientRect();
  const buttonRect = track1.getBoundingClientRect();
  const buttonCenter = buttonRect.left - machineRect.left + buttonRect.width / 2;
  treeArea.style.left = `${buttonCenter - treeArea.offsetWidth / 2}px`;
}

function setTempo(bpm) {
  const min = Number(tempo.min);
  const max = Number(tempo.max);
  const clamped = Math.max(min, Math.min(max, Math.round(bpm)));
  tempo.value = String(clamped);
  tempoValue.value = `${clamped} BPM`;

  const t = (clamped - min) / (max - min);
  const degrees = 135 + t * 270;
  knobIndicator.style.transform = `rotate(${degrees}deg)`;
}

function stepSeconds() {
  // One tree level = one sixteenth note.
  return (60 / Number(tempo.value)) / 4;
}

function makeRandomPath() {
  const path = [0];
  let index = 0;
  for (let level = 1; level < LEVELS; level++) {
    index = index * 2 + (Math.random() < 0.5 ? 0 : 1);
    path.push(index);
  }
  return path;
}

function scheduleVisual(audioTime, fn) {
  const delay = Math.max(0, (audioTime - audioCtx.currentTime) * 1000);
  window.setTimeout(() => {
    if (isPlaying) fn();
  }, delay);
}

function flashNode(level, index, audioTime) {
  scheduleVisual(audioTime, () => {
    const node = nodes[level][index];
    node.classList.remove('playhead');
    void node.offsetWidth;
    node.classList.add('playhead');
    window.setTimeout(() => node.classList.remove('playhead'), Math.min(130, stepSeconds() * 500));
  });
}

function animateBranch(childLevel, childIndex, audioTime, durationSec) {
  scheduleVisual(audioTime, () => {
    const line = branchPulses.get(branchKey(childLevel, childIndex));
    if (!line) return;

    const length = line.getTotalLength();
    line.getAnimations().forEach(a => a.cancel());
    line.style.opacity = '1';
    line.style.strokeDasharray = `${Math.max(10, length * 0.18)} ${length}`;
    line.style.strokeDashoffset = '0';

    line.animate(
      [
        { strokeDashoffset: '0', opacity: 0 },
        { opacity: 1, offset: 0.08 },
        { strokeDashoffset: `${-length}px`, opacity: 1, offset: 0.88 },
        { strokeDashoffset: `${-length}px`, opacity: 0 }
      ],
      { duration: durationSec * 1000, easing: 'linear' }
    );
  });
}

function scheduleStep(time) {
  if (stepIndex === 0 || !currentPath) currentPath = makeRandomPath();

  const level = stepIndex;
  const nodeIndex = currentPath[level];
  flashNode(level, nodeIndex, time);

  if (level < LEVELS - 1) {
    const childIndex = currentPath[level + 1];
    animateBranch(level + 1, childIndex, time, stepSeconds() * 0.96);
  }

  stepIndex = (stepIndex + 1) % LEVELS;
}

function scheduler() {
  while (nextStepTime < audioCtx.currentTime + scheduleAheadSec) {
    scheduleStep(nextStepTime);
    nextStepTime += stepSeconds();
  }
}

async function startSequencer() {
  if (!audioCtx) audioCtx = new AudioContext();
  if (audioCtx.state === 'suspended') await audioCtx.resume();

  isPlaying = true;
  transport.setAttribute('aria-pressed', 'true');
  transport.textContent = 'STOP';
  stepIndex = 0;
  currentPath = null;
  nextStepTime = audioCtx.currentTime + 0.06;
  scheduler();
  schedulerTimer = window.setInterval(scheduler, lookAheadMs);
}

function stopSequencer() {
  isPlaying = false;
  transport.setAttribute('aria-pressed', 'false');
  transport.textContent = 'PLAY';
  if (schedulerTimer) window.clearInterval(schedulerTimer);
  schedulerTimer = null;
  document.querySelectorAll('.node.playhead').forEach(n => n.classList.remove('playhead'));
  document.querySelectorAll('.branch-pulse').forEach(line => {
    line.getAnimations().forEach(a => a.cancel());
    line.style.opacity = '0';
  });
}

track1.addEventListener('click', () => {
  const on = track1.getAttribute('aria-pressed') !== 'true';
  track1.setAttribute('aria-pressed', String(on));
  treeArea.classList.toggle('visible', on);
  treeArea.setAttribute('aria-hidden', String(!on));
  alignTreeToTrack();
});

transport.addEventListener('click', () => {
  if (isPlaying) stopSequencer();
  else startSequencer();
});

tempoKnob.addEventListener('wheel', (event) => {
  event.preventDefault();
  setTempo(Number(tempo.value) + (event.deltaY < 0 ? 1 : -1));
}, { passive: false });

let dragging = false;
let lastY = 0;

tempoKnob.addEventListener('pointerdown', (event) => {
  dragging = true;
  lastY = event.clientY;
  tempoKnob.setPointerCapture(event.pointerId);
});

tempoKnob.addEventListener('pointermove', (event) => {
  if (!dragging) return;
  const delta = lastY - event.clientY;
  if (Math.abs(delta) >= 1) {
    setTempo(Number(tempo.value) + delta);
    lastY = event.clientY;
  }
});

tempoKnob.addEventListener('pointerup', () => { dragging = false; });
tempoKnob.addEventListener('pointercancel', () => { dragging = false; });
tempoKnob.addEventListener('dblclick', () => setTempo(90));

window.addEventListener('resize', alignTreeToTrack);

buildTree();
alignTreeToTrack();
setTempo(Number(tempo.value));
