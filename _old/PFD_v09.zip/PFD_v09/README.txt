PFD — Probabilistic Fractal Drum V0.9

AUDIO FILES
Put all samples in one folder named "audio" beside index.html.

Expected filenames:
  kick1.ogg  kick2.ogg  kick3.ogg  kick4.ogg  kick5.ogg
  snare1.ogg snare2.ogg snare3.ogg snare4.ogg snare5.ogg
  hh1.ogg    hh2.ogg    hh3.ogg    hh4.ogg    hh5.ogg
  perc1.ogg  perc2.ogg  perc3.ogg  perc4.ogg  perc5.ogg

Slot 1 also accepts the older filenames kick.ogg, snare.ogg, hh.ogg and perc.ogg
so an existing V0.7 audio folder still works while you rename things.

The SAMPLE 1–5 selectors switch live. All 20 samples are preloaded on PLAY.
If a selected sample is missing, PFD uses its synthesized fallback for that hit.
