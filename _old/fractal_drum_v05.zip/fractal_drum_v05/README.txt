FRACTAL DRUM V0.5

Put your test samples in the audio folder with these exact filenames:

kick.ogg
snare.ogg
hh.ogg
perc.ogg

If any file is missing, V0.5 uses a synthesized fallback sound for that track.

Controls:
- Main buttons 1-4: show/hide each probability tree. Hiding a tree does NOT stop it.
- Yellow tree buttons: enable/disable trigger points live.
- Hidden tracks that contain active nodes blink on the master BPM.
- MUTE 1-4: suppress audio for that track while its path engine keeps running.
- PLAY/STOP: transport.
- Tempo knob: drag vertically or use mouse wheel. Double-click returns to 90 BPM.

Each tree level = one 16th note. Every track chooses its own random binary path each 4-step cycle.
