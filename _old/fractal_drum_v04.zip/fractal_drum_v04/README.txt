FRACTAL DRUM V0.4

1. Put kick.ogg inside the audio folder.
2. For reliable sample loading, run from a simple local web server or GitHub Pages.
3. If the sample cannot load, the prototype automatically uses a synthesized test kick.
4. Activate Track 1, switch on any yellow nodes, press PLAY.
5. You can click nodes on/off while it is playing. The rhythm changes live.

Tempo: 20-240 BPM. Drag knob vertically, mouse wheel for fine adjustment, double-click resets to 90 BPM.
