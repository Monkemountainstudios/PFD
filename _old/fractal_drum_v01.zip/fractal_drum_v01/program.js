const LEVELS = 4;
const treeArea = document.getElementById('treeArea');
const nodesLayer = document.getElementById('nodes');
const branchesSvg = document.getElementById('branches');
const track1 = document.getElementById('track1');
const tempo = document.getElementById('tempo');
const tempoValue = document.getElementById('tempoValue');
const knobIndicator = document.querySelector('#tempoKnob span');

const W = 260;
const H = 360;
const yLevels = [310, 230, 145, 60]; // root at bottom, branches upward
const nodes = [];

function nodePosition(level, index) {
  const count = 2 ** level;
  const x = ((index + 0.5) / count) * W;
  const y = yLevels[level];
  return { x, y };
}

function buildTree() {
  nodesLayer.innerHTML = '';
  branchesSvg.innerHTML = '';
  nodes.length = 0;

  for (let level = 0; level < LEVELS; level++) {
    const count = 2 ** level;
    nodes[level] = [];

    for (let i = 0; i < count; i++) {
      const { x, y } = nodePosition(level, i);
      const button = document.createElement('button');
      button.className = 'node';
      button.type = 'button';
      button.style.left = `${(x / W) * 100}%`;
      button.style.top = `${(y / H) * 100}%`;
      button.setAttribute('aria-pressed', 'false');
      button.title = `Level ${level + 1}, node ${i + 1}`;
      button.addEventListener('click', () => {
        const isActive = button.classList.toggle('active');
        button.setAttribute('aria-pressed', String(isActive));
      });
      nodesLayer.appendChild(button);
      nodes[level][i] = button;

      if (level > 0) {
        const parentIndex = Math.floor(i / 2);
        const parent = nodePosition(level - 1, parentIndex);
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', parent.x);
        line.setAttribute('y1', parent.y);
        line.setAttribute('x2', x);
        line.setAttribute('y2', y);
        line.setAttribute('class', 'branch');
        branchesSvg.appendChild(line);
      }
    }
  }
}

function updateTempoVisual() {
  const bpm = Number(tempo.value);
  tempoValue.value = `${bpm} BPM`;
  const t = (bpm - 20) / (240 - 20);
  const degrees = -140 + t * 280;
  knobIndicator.style.transform = `rotate(${degrees}deg)`;
}

track1.addEventListener('click', () => {
  const on = track1.getAttribute('aria-pressed') !== 'true';
  track1.setAttribute('aria-pressed', String(on));
  treeArea.classList.toggle('visible', on);
  treeArea.setAttribute('aria-hidden', String(!on));
});

tempo.addEventListener('input', updateTempoVisual);

buildTree();
updateTempoVisual();
